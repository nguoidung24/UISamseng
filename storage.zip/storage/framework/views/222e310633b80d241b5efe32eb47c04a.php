<?php $__currentLoopData = $fillable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($key != 'product_id'): ?>
        <div>
            <label for=""><?php echo e($Field[$item]); ?></label>
            <?php if($key == 'color_id'): ?>
                <div class="relative">
                    <select class="input input-bordered w-full mt-2 " id="_<?php echo e($key); ?>">
                        <option disabled value="<?php echo e($product[$key]); ?>" selected>
                            <?php echo e($product['color']['value']); ?></option>
                    </select>
                    <p id="changeColor" class="absolute size-5 top-5 right-2 border-2 border-base-content"
                        style="background-color:  <?php echo e($product['color']['value']); ?>"> </p>
                    <p id="changeColor" class="absolute size-5 top-5 right-2 border-2 border-base-content">
                    </p>
                </div>
            <?php elseif($key == 'thumbnail'): ?>
                <div class="relative text-center">
                    <label for="_<?php echo e($key); ?>">
                        <img id="__<?php echo e($key); ?>" class="w-20 h-22 mx-auto hover:cursor-pointer hover:scale-95"
                            src="/<?php echo e($product[$key]); ?>" alt="">
                    </label>
                    <input name="img-product" id="_<?php echo e($key); ?>" type="file" value="<?php echo e($product[$key]); ?>"
                        class="mx-auto file:opacity-0 file:size-12" />
                </div>
            <?php elseif($key == 'category_id'): ?>
                <select class="input input-bordered w-full mt-2 " id="_<?php echo e($key); ?>">
                    <option disabled value="<?php echo e($product[$key]); ?>" selected>
                        <?php echo e($product['category']['category_name']); ?></option>
                </select>
            <?php else: ?>
                <input id="_<?php echo e($key); ?>" type="text" value="<?php echo e($product[$key]); ?>"
                    class="input input-bordered w-full mt-2 " />
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Xampp\htdocs\my_store\my_store\resources\views/Components/edit_products/edit.blade.php ENDPATH**/ ?>