

<?php
    $Field = ['Thumbnail', 'Product ID', 'Color', 'Category', 'Product Name', 'Product Type', 'Sold', 'Price', 'Rating', 'Total Rating', 'Status', 'Discount', 'Quantity'];
    $fillable = ['thumbnail', 'product_id', 'color_id', 'category_id', 'product_name', 'product_type', 'sold', 'price', 'rating', 'total_rating', 'status', 'discount', 'quantity'];
    function generateRandomNumberId($length = 10)
    {
        $characters = '0123456789';
        $charactersLength = strlen($characters);

        $result = '';

        for ($i = 0; $i < $length; $i++) {
            $result .= $characters[random_int(0, $charactersLength - 1)];
        }

        return $result;
    }
    $randomId = generateRandomNumberId();
    $product = $data['data'][0] != 'new' ? $data['data'][0] : 'new';
?>
<?php $__env->startSection('content'); ?>
    <div class="p-2 lg:px-16">
        <p class="text-2xl text-center my-6 font-semibold">Sửa Sản Phẩm</p>
        <p onclick="window.history.go(-1);" class="btn btn-link"> ← Quay lại</p>
        <form id="formSubmit" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 lg:gap-8 gap-2">
            <?php if($product != 'new'): ?>
                <?php echo $__env->make('Components.edit_products.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('Components.edit_products.new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <div class="text-center">
                <button class="btn w-36 btn-success">
                    Xong
                </button>
            </div>
        </form>
    </div>
    <script>
        const request = {
            'action': "",
            'thumbnail': "",
            'product_id': "",
            'color_id': "",
            'product_name': "",
            'category_id': "",
            'product_type': "",
            'sold': "",
            'price': "",
            'rating': "",
            'total_rating': "",
            'status': "",
            'discount': "",
            'quantity': "",
        }
        
        var onSubmit = async function(event) {
            event.preventDefault();
            try {
                <?php if($product != 'new'): ?>
                    for (item in request) {
                        if (item == 'product_id') {
                            request[item] = <?php echo $product['product_id']; ?>
                        } else if (item == 'thumbnail') {
                            request[item] = '<?php echo $product['thumbnail']; ?>'
                        } else if (item != 'action')
                            request[item] = document.getElementById("_" + item).value
                    }
                    request['action'] = 'update';
                <?php else: ?>
                    for (item in request) {
                        if (item != 'action')
                            request[item] = document.getElementById("_" + item).value
                    }
                    request['action'] = 'create';
                <?php endif; ?>
                console.log(request);
                const image = document.getElementById('_thumbnail');
                const imageUpload = image.files[0];
                let formData = new FormData();
                formData.append("image", imageUpload);
                formData.append("product", "product");
                if (imageUpload) {
                    let uploadImage = await axios.post('/api/upload', formData)
                    request.thumbnail = uploadImage?.data;
                }
                let response = await axios.post('/products', request);
                await Swal.fire("Đã Xong!", "", "success");
                // location.href = '/products'
            } catch (error) {
                try {
                    let responseData = error.response?.data?.errors;
                    for (item in request) {
                        if (item != 'action')
                            document.getElementById(item).innerText = responseData[item] == undefined ? '' :
                            responseData[item]
                    }
                } catch (error) {
                    console.log("errors");
                }

            }
        };
        var form = document.getElementById("formSubmit");
        form.addEventListener("submit", onSubmit, true);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.tpl_default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\my_store\my_store\resources\views/edit_products.blade.php ENDPATH**/ ?>