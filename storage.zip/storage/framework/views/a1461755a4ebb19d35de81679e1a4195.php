

<?php $__env->startSection('content'); ?>
<div>
    <p class="text-center"> <?php echo e($data['data'][0]->product_name); ?> </p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.tpl_default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\my_store\my_store\resources\views/news.blade.php ENDPATH**/ ?>