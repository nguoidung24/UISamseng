
<?php
    $Field = ['#', 'Tên', 'Thumbnail', 'Màu', 'Category', 'Kiểu', 'Đã bán', 'Giá (vnđ)', 'Rating', 'Total Rating', 'Status', 'Giảm giá', 'Số lượng', 'Created At', 'Updated At'];
    $fillable = ['product_id', 'product_name', 'thumbnail', 'color', 'category', 'product_type', 'sold', 'price', 'rating', 'total_rating', 'status', 'discount', 'quantity', 'created_at', 'updated_at'];
    $response = $data['data'];
    $search = '';
    if (isset($data['search'])) {
        $search = $data['search'];
    }
?>

<?php $__env->startSection('content'); ?>
    <div>
        <div class="my-scroll min-h-[50vh]">
            <p class="text-center my-5 font-semibold text-2xl">
                Danh Sách Sản Phẩm
            </p>
            <div class="flex justify-between px-4 py-2">
                <div class=" w-[300px]">
                    <a class="btn btn-link text-base-content" href="/edit_products/new"> + Thêm mới</a>
                </div>
                <?php if($search): ?>
                    <form action="/products" class='italic'>
                        Hiển thị kết quả tìm kiếm cho: "<span class="font-semibold text-lg"><?php echo e($search); ?></span>"
                        <div class="tooltip" data-tip="Bỏ tìm">
                            <button class="py-1 px-2 text-red-500">x</button>
                        </div>
                    </form>
                <?php endif; ?>
                <form action="/products" class="w-[300px] relative">
                    <input value="<?php echo e($search); ?>" autocomplete="off" type="text" placeholder="Tìm Kiếm"
                        class="input input-bordered pe-14 w-[300px]" name="search" />
                    <button class="btn btn-ghost absolute top-0 right-0">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                    </button>
                </form>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <?php $__currentLoopData = $Field; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($item); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $response['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr name="row-products" data-id='<?php echo e($item->product_id); ?>'
                            data-href='/products<?php echo e('?search=' . $search); ?>'
                            class="hover:bg-base-300 text-center hover:cursor-pointer">
                            <?php $__currentLoopData = $fillable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key == 'thumbnail'): ?>
                                    <td>
                                        <img class="h-12 w-10" src="<?php echo e($item[$key]); ?>" alt="">
                                    </td>
                                <?php elseif($key == 'color'): ?>
                                    <td>
                                        <div class="tooltip" data-tip="<?php echo e($item[$key]['value']); ?>">
                                            <p class="size-8 rounded-full mx-auto border-2 border-base-content"
                                                style="background-color: <?php echo e($item[$key]['value']); ?>"></p>
                                        </div>
                                    </td>
                                <?php elseif($key == 'category'): ?>
                                    <td> <?php echo e($item[$key]['category_name']); ?> </td>
                                <?php elseif($key == 'price'): ?>
                                    <td><?php echo e(number_format($item[$key], 0, ',', '.')); ?></td>
                                <?php else: ?>
                                    <td><?php echo e($item[$key] == '' ? '_' : $item[$key]); ?></td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="flex justify-center">
            <form action="/products" method="get" class="join mt-5 mb-2">
                <button value="<?php echo e((int) $response['pageIndex'] - 1); ?>" name="page"
                    class="join-item btn <?php echo e($response['pageIndex'] <= 1 ? 'btn-disabled' : ''); ?>">
                    «
                </button>
                <?php if($search): ?>
                    <?php echo '<input class="scale-0 opacity-0 size-0" type="text" value="' . $search . '" name="search">'; ?>

                <?php endif; ?>
                <button id="change-page" type="button" data-href="/products<?php echo e('?search=' . $search); ?>"
                    data-totalPage="<?php echo $response['totalPage']; ?>" class="join-item btn">
                    Trang <?php echo e($response['pageIndex']); ?>

                </button>
                <button value="<?php echo e((int) $response['pageIndex'] + 1); ?>" name="page"
                    class="join-item btn <?php echo e($response['pageIndex'] >= $response['totalPage'] ? 'btn-disabled' : ''); ?>">
                    »
                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.tpl_default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\my_store\my_store\resources\views/products.blade.php ENDPATH**/ ?>