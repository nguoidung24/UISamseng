<div class="mt-6">
    <figure>
        <img class="size-12 mx-auto" src="/assets/image/aniUser.gif" alt="">
    </figure>
    <p class="text-center font-bold">Admin</p>
</div>
<ul id="menu-dashboard" class="menu rounded-box">
    <?php echo $__env->make('Components.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</ul>
<?php /**PATH D:\Xampp\htdocs\my_store\my_store\resources\views/Components/Home/left.blade.php ENDPATH**/ ?>