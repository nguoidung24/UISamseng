

<?php $__env->startSection('content'); ?>
    <main class="min-h-screen my-dasboard">
        <div
            class="grid lg:border min-h-[600px] lg:overflow-hidden lg:mx-20 lg:my-5 lg:border-base-content lg:rounded-lg grid-cols-12">
            <div class="lg:col-span-2 bg-base-200 my-bg border-e border-base-content lg:block hidden">
                <?php echo $__env->make('Components.Home.left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="lg:col-span-10 col-span-full">
                <?php echo $__env->make('Components.Home.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </main>
    <script>
       
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.tpl_default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\my_store\my_store\resources\views/home.blade.php ENDPATH**/ ?>