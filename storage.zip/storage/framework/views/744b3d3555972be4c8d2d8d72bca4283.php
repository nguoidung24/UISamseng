<?php $__currentLoopData = $fillable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="">
        <label for=""><?php echo e($Field[$item]); ?></label>
        <?php if($key == 'thumbnail'): ?>
            <div class="relative text-center">
                <label for="_<?php echo e($key); ?>">
                    <img id="__<?php echo e($key); ?>" class="w-20 h-22 mx-auto hover:cursor-pointer hover:scale-95"
                        src="/assets/image/img-plus.svg" alt="">
                </label>
                <input name="img-product" id="_<?php echo e($key); ?>" type="file" value=""
                    class="mx-auto file:opacity-0 file:size-12" />
            </div>
        <?php elseif($key == 'product_id'): ?>
            <input id="_<?php echo e($key); ?>" type="text" value="<?php echo e($randomId); ?>"
                class="input input-bordered w-full mt-2 " />
        <?php elseif($key == 'color_id'): ?>
            <div class="relative">
                <select class="input input-bordered w-full mt-2 " id="_<?php echo e($key); ?>">
                    <option disabled value="" selected>-- Chọn Màu --</option>
                </select>
                <p id="changeColor" class="absolute size-5 top-5 right-2"> </p>
            </div>
        <?php elseif($key == 'category_id'): ?>
            <select class="input input-bordered w-full mt-2 " id="_<?php echo e($key); ?>">
                <option disabled value="" selected>-- Chọn Category --</option>
            </select>
        <?php else: ?>
            <input id="_<?php echo e($key); ?>" type="text" value="" class="input input-bordered w-full mt-2 " />
        <?php endif; ?>
        <p class="italic text-red-600" id='<?php echo e($fillable[$item]); ?>'></p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Xampp\htdocs\my_store\my_store\resources\views/Components/edit_products/new.blade.php ENDPATH**/ ?>