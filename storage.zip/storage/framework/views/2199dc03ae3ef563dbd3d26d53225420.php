<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Tiêu đề trang</title>
    <link rel="stylesheet" href="đường_dẫn_tới_file_css" media="all">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

</head>

<body>
    <h2>Tiêu đề từ template</h2>
    <?php echo $__env->yieldContent('content'); ?>

</body>

</html><?php /**PATH D:\Xampp\htdocs\my_store\my_store\resources\views/tpl_default.blade.php ENDPATH**/ ?>